﻿using System;
using System.Collections.Generic;

namespace Learnify.Data;

public partial class Stddatum
{
    public string? Subject { get; set; }

    public int? Modules { get; set; }

    public string? Topic { get; set; }

    public string? Ytvideo { get; set; }

    public long? Sem { get; set; }
}
